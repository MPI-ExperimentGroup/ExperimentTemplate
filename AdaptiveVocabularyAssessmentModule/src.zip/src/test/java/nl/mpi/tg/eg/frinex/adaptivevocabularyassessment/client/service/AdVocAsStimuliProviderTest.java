/*
 * Copyright (C) 2019 Max Planck Institute for Psycholinguistics, Nijmegen
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
package nl.mpi.tg.eg.frinex.adaptivevocabularyassessment.client.service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import nl.mpi.tg.eg.frinex.adaptivevocabularyassessment.client.generic.BookkeepingStimulus;
import nl.mpi.tg.eg.frinex.adaptivevocabularyassessment.client.model.vocabulary.AdVocAsStimulus;
import nl.mpi.tg.eg.frinex.adaptivevocabularyassessment.client.service.advocaspool.FastTrackShablonElement;
import nl.mpi.tg.eg.frinex.adaptivevocabularyassessment.client.service.advocaspool.FineTuningShablonElement;
import nl.mpi.tg.eg.frinex.common.model.Stimulus;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.Ignore;

/**
 *
 * @author olhshk
 */
public class AdVocAsStimuliProviderTest {
    
    public AdVocAsStimuliProviderTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of initialiseStimuliState method, of class AdVocAsStimuliProvider.
     */
   @Test
    public void testInitialiseStimuliState() {
        System.out.println("initialiseStimuliState");
        String stimuliStateSnapshot = "";
        AdVocAsStimulus[] stimului ={null};
        AdVocAsStimuliProvider instance = new AdVocAsStimuliProvider(stimului);
        instance.initialiseStimuliState(stimuliStateSnapshot);
        
        assertEquals(0, instance.getBandIndexScore());
        
        AdVocAsStimulus stimulus =  instance.getCurrentStimulus();
        System.out.println("end");
    }

    /**
     * Test of setmaxDurationMinutes method, of class AdVocAsStimuliProvider.
     */
    @Ignore
   @Test
    public void testSetmaxDurationMinutes() {
        System.out.println("setmaxDurationMinutes");
        String maxDurationMinutes = "";
        AdVocAsStimuliProvider instance = null;
        instance.setmaxDurationMinutes(maxDurationMinutes);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setnumberOfBands method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testSetnumberOfBands() {
        System.out.println("setnumberOfBands");
        String nBands = "";
        AdVocAsStimuliProvider instance = null;
        instance.setnumberOfBands(nBands);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setfineTuningUpperBoundForCycles method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testSetfineTuningUpperBoundForCycles() {
        System.out.println("setfineTuningUpperBoundForCycles");
        String uBound = "";
        AdVocAsStimuliProvider instance = null;
        instance.setfineTuningUpperBoundForCycles(uBound);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setwordsSource method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testSetwordsSource() {
        System.out.println("setwordsSource");
        String wordsSource = "";
        AdVocAsStimuliProvider instance = null;
        instance.setwordsSource(wordsSource);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setnonwordsSource method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testSetnonwordsSource() {
        System.out.println("setnonwordsSource");
        String nonwordsSource = "";
        AdVocAsStimuliProvider instance = null;
        instance.setnonwordsSource(nonwordsSource);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setfastTrackShablonSource method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testSetfastTrackShablonSource() {
        System.out.println("setfastTrackShablonSource");
        String fastTrackShablonSource = "";
        AdVocAsStimuliProvider instance = null;
        instance.setfastTrackShablonSource(fastTrackShablonSource);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setnfineTuningShablonSource method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testSetnfineTuningShablonSource() {
        System.out.println("setnfineTuningShablonSource");
        String fineTuningShablonSource = "";
        AdVocAsStimuliProvider instance = null;
        instance.setnfineTuningShablonSource(fineTuningShablonSource);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isCorrectResponse method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testIsCorrectResponse() {
        System.out.println("isCorrectResponse");
        Stimulus stimulus = null;
        String stimulusResponse = "";
        AdVocAsStimuliProvider instance = null;
        boolean expResult = false;
        boolean result = instance.isCorrectResponse(stimulus, stimulusResponse);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCurrentStimulusUniqueId method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetCurrentStimulusUniqueId() {
        System.out.println("getCurrentStimulusUniqueId");
        AdVocAsStimuliProvider instance = null;
        String expResult = "";
        String result = instance.getCurrentStimulusUniqueId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateStimuliStateSnapshot method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGenerateStimuliStateSnapshot() {
        System.out.println("generateStimuliStateSnapshot");
        AdVocAsStimuliProvider instance = null;
        String expResult = "";
        String result = instance.generateStimuliStateSnapshot();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of setCurrentStimuliIndex method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testSetCurrentStimuliIndex() {
        System.out.println("setCurrentStimuliIndex");
        int currentStimuliIndex = 0;
        AdVocAsStimuliProvider instance = null;
        instance.setCurrentStimuliIndex(currentStimuliIndex);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCurrentStimulusIndex method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetCurrentStimulusIndex() {
        System.out.println("getCurrentStimulusIndex");
        AdVocAsStimuliProvider instance = null;
        int expResult = 0;
        int result = instance.getCurrentStimulusIndex();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getCurrentStimulus method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetCurrentStimulus() {
        System.out.println("getCurrentStimulus");
        AdVocAsStimuliProvider instance = null;
        AdVocAsStimulus expResult = null;
        AdVocAsStimulus result = instance.getCurrentStimulus();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTotalStimuli method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetTotalStimuli() {
        System.out.println("getTotalStimuli");
        AdVocAsStimuliProvider instance = null;
        int expResult = 0;
        int result = instance.getTotalStimuli();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of hasNextStimulus method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testHasNextStimulus() {
        System.out.println("hasNextStimulus");
        int increment = 0;
        AdVocAsStimuliProvider instance = null;
        boolean expResult = false;
        boolean result = instance.hasNextStimulus(increment);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of nextStimulus method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testNextStimulus() {
        System.out.println("nextStimulus");
        int increment = 0;
        AdVocAsStimuliProvider instance = null;
        instance.nextStimulus(increment);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of fastTrackToBeContinued method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testFastTrackToBeContinued() {
        System.out.println("fastTrackToBeContinued");
        AdVocAsStimuliProvider instance = null;
        boolean expResult = false;
        boolean result = instance.fastTrackToBeContinued();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of initialiseNextFineTuningTuple method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testInitialiseNextFineTuningTuple() {
        System.out.println("initialiseNextFineTuningTuple");
        AdVocAsStimuliProvider instance = null;
        boolean expResult = false;
        boolean result = instance.initialiseNextFineTuningTuple();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of fineTuningToBeContinued method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testFineTuningToBeContinued() {
        System.out.println("fineTuningToBeContinued");
        AdVocAsStimuliProvider instance = null;
        boolean expResult = false;
        boolean result = instance.fineTuningToBeContinued();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of isTimeOut method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testIsTimeOut() {
        System.out.println("isTimeOut");
        AdVocAsStimuliProvider instance = null;
        boolean expResult = false;
        boolean result = instance.isTimeOut();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStimuliReport method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetStimuliReport() {
        System.out.println("getStimuliReport");
        String reportType = "";
        AdVocAsStimuliProvider instance = null;
        Map<String, String> expResult = null;
        Map<String, String> result = instance.getStimuliReport(reportType);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBandIndexScore method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetBandIndexScore() {
        System.out.println("getBandIndexScore");
        AdVocAsStimuliProvider instance = null;
        int expResult = 0;
        int result = instance.getBandIndexScore();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getWords method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetWords() {
        System.out.println("getWords");
        AdVocAsStimuliProvider instance = null;
        ArrayList<ArrayList<AdVocAsStimulus>> expResult = null;
        ArrayList<ArrayList<AdVocAsStimulus>> result = instance.getWords();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getNonwords method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetNonwords() {
        System.out.println("getNonwords");
        AdVocAsStimuliProvider instance = null;
        ArrayList<AdVocAsStimulus> expResult = null;
        ArrayList<AdVocAsStimulus> result = instance.getNonwords();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFastTrackSceletone method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetFastTrackSceletone() {
        System.out.println("getFastTrackSceletone");
        AdVocAsStimuliProvider instance = null;
        ArrayList<FastTrackShablonElement> expResult = null;
        ArrayList<FastTrackShablonElement> result = instance.getFastTrackSceletone();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFineTuningSceletone method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetFineTuningSceletone() {
        System.out.println("getFineTuningSceletone");
        AdVocAsStimuliProvider instance = null;
        ArrayList<FineTuningShablonElement> expResult = null;
        ArrayList<FineTuningShablonElement> result = instance.getFineTuningSceletone();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPercentageBandTable method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetPercentageBandTable() {
        System.out.println("getPercentageBandTable");
        AdVocAsStimuliProvider instance = null;
        LinkedHashMap<Long, Integer> expResult = null;
        LinkedHashMap<Long, Integer> result = instance.getPercentageBandTable();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of bandNumberIntoPercentage method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testBandNumberIntoPercentage() {
        System.out.println("bandNumberIntoPercentage");
        int bandNumber = 0;
        AdVocAsStimuliProvider instance = null;
        long expResult = 0L;
        long result = instance.bandNumberIntoPercentage(bandNumber);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of percentageIntoBandNumber method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testPercentageIntoBandNumber() {
        System.out.println("percentageIntoBandNumber");
        long percentage = 0L;
        AdVocAsStimuliProvider instance = null;
        int expResult = 0;
        int result = instance.percentageIntoBandNumber(percentage);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of analyseCorrectness method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testAnalyseCorrectness() {
        System.out.println("analyseCorrectness");
        Stimulus stimulus = null;
        String stimulusResponse = "";
        AdVocAsStimuliProvider instance = null;
        boolean expResult = false;
        boolean result = instance.analyseCorrectness(stimulus, stimulusResponse);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of recycleUnusedStimuli method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testRecycleUnusedStimuli() {
        System.out.println("recycleUnusedStimuli");
        AdVocAsStimuliProvider instance = null;
        instance.recycleUnusedStimuli();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toBeContinuedLoopAndLooserChecker method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testToBeContinuedLoopAndLooserChecker() {
        System.out.println("toBeContinuedLoopAndLooserChecker");
        AdVocAsStimuliProvider instance = null;
        boolean expResult = false;
        boolean result = instance.toBeContinuedLoopAndLooserChecker();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of detectLoop method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testDetectLoop() {
        System.out.println("detectLoop");
        Integer[] arr = null;
        boolean expResult = false;
        boolean result = AdVocAsStimuliProvider.detectLoop(arr);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of shiftFIFO method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testShiftFIFO() {
        System.out.println("shiftFIFO");
        Integer[] fifo = null;
        int newelement = 0;
        AdVocAsStimuliProvider.shiftFIFO(fifo, newelement);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mostOftenVisitedBandIndex method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testMostOftenVisitedBandIndex() {
        System.out.println("mostOftenVisitedBandIndex");
        Integer[] bandVisitCounter = null;
        int controlIndex = 0;
        int expResult = 0;
        int result = AdVocAsStimuliProvider.mostOftenVisitedBandIndex(bandVisitCounter, controlIndex);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStringFastTrack method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetStringFastTrack() {
        System.out.println("getStringFastTrack");
        String startRow = "";
        String endRow = "";
        String startColumn = "";
        String endColumn = "";
        AdVocAsStimuliProvider instance = null;
        String expResult = "";
        String result = instance.getStringFastTrack(startRow, endRow, startColumn, endColumn);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStringFineTuningHistory method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetStringFineTuningHistory() {
        System.out.println("getStringFineTuningHistory");
        String startRow = "";
        String endRow = "";
        String startColumn = "";
        String endColumn = "";
        String format = "";
        AdVocAsStimuliProvider instance = null;
        String expResult = "";
        String result = instance.getStringFineTuningHistory(startRow, endRow, startColumn, endColumn, format);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getHtmlStimuliReport method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetHtmlStimuliReport() {
        System.out.println("getHtmlStimuliReport");
        AdVocAsStimuliProvider instance = null;
        String expResult = "";
        String result = instance.getHtmlStimuliReport();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPercentageScore method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetPercentageScore() {
        System.out.println("getPercentageScore");
        AdVocAsStimuliProvider instance = null;
        long expResult = 0L;
        long result = instance.getPercentageScore();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateDiagramSequence method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGenerateDiagramSequence() {
        System.out.println("generateDiagramSequence");
        ArrayList<BookkeepingStimulus<AdVocAsStimulus>> records = null;
        LinkedHashMap<Long, Integer> percentageBandTable = null;
        AdVocAsStimuliProvider instance = null;
        LinkedHashMap<Long, String> expResult = null;
        LinkedHashMap<Long, String> result = instance.generateDiagramSequence(records, percentageBandTable);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of retrieveSampleWords method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testRetrieveSampleWords() {
        System.out.println("retrieveSampleWords");
        ArrayList<BookkeepingStimulus<AdVocAsStimulus>> records = null;
        ArrayList<ArrayList<AdVocAsStimulus>> nonusedWords = null;
        AdVocAsStimuliProvider instance = null;
        LinkedHashMap<Integer, String> expResult = null;
        LinkedHashMap<Integer, String> result = instance.retrieveSampleWords(records, nonusedWords);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of toString method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testToString() {
        System.out.println("toString");
        AdVocAsStimuliProvider instance = null;
        String expResult = "";
        String result = instance.toString();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of deserialise method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testDeserialise() throws Exception {
        System.out.println("deserialise");
        String str = "";
        AdVocAsStimuliProvider instance = null;
        instance.deserialise(str);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getBandIndexScoreByVisits method, of class AdVocAsStimuliProvider.
     */
   @Ignore @Test
    public void testGetBandIndexScoreByVisits() {
        System.out.println("getBandIndexScoreByVisits");
        Integer[] visitCounter = null;
        AdVocAsStimuliProvider instance = null;
        int expResult = 0;
        int result = instance.getBandIndexScoreByVisits(visitCounter);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
